package com.example.zillowpropertysearch;


import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.JSONException;
import org.json.JSONObject;

import android.support.v7.app.ActionBarActivity;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.*;
import android.app.ActionBar.LayoutParams;
import android.app.AlertDialog;
//import android.app.Fragment;
//import android.app.FragmentManager;
//import android.app.FragmentTransaction;
import android.widget.ViewSwitcher.ViewFactory;

public class ResultActivity extends ActionBarActivity {
	
	//Declarations//
	private ImageSwitcher imageSwitcher;
   // private ImageButton img;
    private int counter = 0;
    private String[] imgUrl = new String[3];
    private TextView zest_info;
    Button facebookShare;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_result);
		
		try {
			Intent intent = getIntent();
		    String message = intent.getStringExtra("data");
	    
		    TabHost tabs = (TabHost)findViewById(android.R.id.tabhost);
		    tabs.setup();
		    
		    /*for basic info*/
		    TabHost.TabSpec basic_info = tabs.newTabSpec("Basic Info");
		    basic_info.setContent(R.id.basic_info);
		    basic_info.setIndicator("Basic Info");
		    tabs.addTab(basic_info);
	    
	    /*parsing the Json Object which was converted to string, converting it back to json object*/
		    
			JSONObject jsonResult = new JSONObject(message);
			final String homedetails = jsonResult.getString("homedetails");
			final String street = jsonResult.getString("street");
			final String cityName = jsonResult.getString("city");
			final String stateName = jsonResult.getString("state");
			final String zipCode = jsonResult.getString("zipcode");
			TextView detailsObj = (TextView)findViewById(R.id.homedetails);
			detailsObj.setText(Html.fromHtml("<a href='"+homedetails+"'style='text-decoration:none;' target='_BLANK' id='linkZillow'>"+street+", "+cityName+", "+stateName+" - "+zipCode+"</a>"));
			detailsObj.setMovementMethod(LinkMovementMethod.getInstance());
			/* for property type*/
			TextView propertyTypeObj = (TextView)findViewById(R.id.type);
			propertyTypeObj.setText(jsonResult.getString("propertyType"));
			
			/*for year built*/
			TextView yearBuiltObj = (TextView)findViewById(R.id.builtYear);
			yearBuiltObj.setText(jsonResult.getString("yearBuilt"));
			
			/* for lot size*/
			TextView lotSizeObj = (TextView)findViewById(R.id.lotsize);
			lotSizeObj.setText(jsonResult.getString("lotSize"));
			
			/*for finished area*/
			TextView finishedAreaObj = (TextView)findViewById(R.id.finishedArea);
			finishedAreaObj.setText(jsonResult.getString("finishedArea"));
			
			/*bathrooms*/
			TextView bathRoomObj = (TextView)findViewById(R.id.bathrooms);
			bathRoomObj.setText(jsonResult.getString("bathrooms"));
			/*bedrooms*/
			TextView bedRoomObj = (TextView)findViewById(R.id.bedrooms);
			bedRoomObj.setText(jsonResult.getString("bedrooms"));
			
			/* tax assessment year*/
			TextView taxAssessmentYrObj = (TextView)findViewById(R.id.taxAssYear);
			taxAssessmentYrObj.setText(jsonResult.getString("taxAssessmentYear"));
			
			/*tax assessment*/
			TextView taxAssessmentObj = (TextView)findViewById(R.id.taxAss);
			taxAssessmentObj.setText(jsonResult.getString("taxAssessment"));
			
			/* last sold price*/
			TextView lastSoldObj = (TextView)findViewById(R.id.lastSoldPrice);
			lastSoldObj.setText(jsonResult.getString("lastSoldPrice"));
			final String lastSoldPrice = jsonResult.getString("lastSoldPrice");
			
			/*last sold date*/
			TextView lastSoldDateObj = (TextView)findViewById(R.id.lastSoldDate);
			lastSoldDateObj.setText(jsonResult.getString("lastSoldDate"));
			
			/* for zestimate prop estimate*/
			TextView zestimateDate = (TextView)findViewById(R.id.zestimatePropertyEstimateDate);
			zestimateDate.setText(Html.fromHtml("Zestimate &reg Property Estimate as of "+jsonResult.getString("zestimatePropEstimateDate")));
			zestimateDate.setMovementMethod(LinkMovementMethod.getInstance());
			
			/*zestimate prop estimate value*/
			TextView zestimateValue = (TextView)findViewById(R.id.zestimatePropertyEstimateValue);
			zestimateValue.setText(jsonResult.getString("zestimatePropEstimateVal"));
			
			final String facebookValue = jsonResult.getString("facebookValue").trim();
			
			/*image for 30 days change*/
			ImageView img1 = (ImageView)findViewById(R.id.imageIndicator);
			if(jsonResult.getString("thirtyDaysOverallChangeSymbol").trim().equalsIgnoreCase("UP")){
				img1.setImageResource(R.drawable.up_g);
			}
			else{
				img1.setImageResource(R.drawable.down_r);
			}
			/*30day change Value*/
			TextView thirtyOvrAllChange1 = (TextView)findViewById(R.id.thirtyOverallChange);
			thirtyOvrAllChange1.setText(jsonResult.getString("thirtyDaysOverallChange"));
			final String overAllChange = jsonResult.getString("thirtyDaysOverallChange");
			/* All time property range*/
			//allTimeRange
			TextView allTimePropertyRange = (TextView)findViewById(R.id.allTimeRange);
			allTimePropertyRange.setText(jsonResult.getString("allTimePropRangeLow")+"-"+jsonResult.getString("allTimePropRangeHigh"));
			
			/*rent zestimate date*/
			TextView rentZestimateDate = (TextView)findViewById(R.id.rentZestimateDate);
			rentZestimateDate.setText(Html.fromHtml("Rent Zestimate &reg  Valuation as of "+jsonResult.getString("rentZestimateDate")));
			//rentZestimateDate.setMovementMethod(LinkMovementMethod.getInstance());
			/* rent zestimate Value*/
			TextView rentZestimateValue = (TextView)findViewById(R.id.rentZestimateValue);
			rentZestimateValue.setText(jsonResult.getString("rentZestimateVal"));
			
			/*rent change*/
			ImageView img2 = (ImageView)findViewById(R.id.imgIndicator2);
			if(jsonResult.getString("thirtyDaysRentChangeSymbol").trim().equalsIgnoreCase("UP")){
				img2.setImageResource(R.drawable.up_g);
			}
			else{
				img2.setImageResource(R.drawable.down_r);
			}
			/*30day change Value*/
			TextView thirtyOvrAllRentChange = (TextView)findViewById(R.id.rentChange);
			thirtyOvrAllRentChange.setText(jsonResult.getString("thirtyDaysRentChange"));
			
			/*rent range*/
			TextView allTimeRentRange = (TextView)findViewById(R.id.rentRange);
			allTimeRentRange.setText(jsonResult.getString("allTimeRentRangeLow")+"-"+jsonResult.getString("allTimeRentRangeHigh"));
			
			
	    
	    
		    /* for historical estimates*/
		    
			
			imageSwitcher = (ImageSwitcher)findViewById(R.id.imageSwitcher1);
			imgUrl[0] = jsonResult.getString("oneYearImage");
			imgUrl[1] = jsonResult.getString("fiveYearImage");
			imgUrl[2] = jsonResult.getString("tenYearImage");
			
			imageSwitcher.setFactory(new ViewFactory() {

		    	   @Override
		    	   public View makeView() {
		    	      ImageView myView = new ImageView(getApplicationContext());
		    	      //LayoutParams params = (LayoutParams)myView.getLayoutParams();
		    	     // params.width=220;
		    	     // params.height=200;
		    	     myView.setScaleType(ImageView.ScaleType.FIT_XY);
		    	    // myView.setScaleType(ImageView.ScaleType.CENTER_CROP);
		    	      //myView.setLayoutParams(params);
		    	     myView.setLayoutParams(new ImageSwitcher.LayoutParams(LayoutParams.
		    	      MATCH_PARENT,LayoutParams.MATCH_PARENT));
		    	      return myView;
		    	       }

		    	   });
			
			
		    TabHost.TabSpec historical_zestimates = tabs.newTabSpec("Historical Zestimates");
		    historical_zestimates.setContent(R.id.hist_zestimates);
		    historical_zestimates.setIndicator("Historical Zestimates");
		    tabs.addTab(historical_zestimates);
		    new ImageLoadTask(imgUrl[0], imageSwitcher).execute();
		    
		    zest_info = (TextView)findViewById(R.id.zest_info);
		    zest_info.setText("Historical Zestimate for the past 1 year");
		    TextView prop_info = (TextView)findViewById(R.id.prop_info);
		    prop_info.setText(street+", "+cityName+", "+stateName+"-"+zipCode);
		    
		    facebookShare = (Button) findViewById(R.id.fbShare);
		    facebookShare.setOnClickListener(new OnClickListener() {
				
		    	@SuppressWarnings("deprecation")
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
		    		AlertDialog alert=new AlertDialog.Builder(ResultActivity.this).create();
					
					alert.setTitle("Post To Facebook");
					alert.setButton("Post Property Details", new DialogInterface.OnClickListener() {

		                public void onClick(DialogInterface dialog, int which) {
		                	startFBActivity(street, cityName, stateName, zipCode, homedetails, lastSoldPrice, overAllChange, imgUrl[0],facebookValue);
		                	dialog.dismiss();
		                }
		            });
					alert.setButton2("Cancel", new DialogInterface.OnClickListener() {

		                public void onClick(DialogInterface dialog, int which) {
		                    // TODO Auto-generated method stub
		                	dialog.dismiss();
		                }
		            });

		            alert.show();
		           
					
				}
			});
		    
		    TextView zillowFoot = (TextView)findViewById(R.id.zillowFooter);
			zillowFoot.setText(Html.fromHtml("<p>&copy Zillow, Inc., 2006-2014.<br> Use is subject to <a href='http://www.zillow.com/corp/Terms.htm'>Terms of Use</a><br><a href='http://www.zillow.com/zestimate/'>What's a Zestimate?</a></p>"));
			zillowFoot.setMovementMethod(LinkMovementMethod.getInstance());
		    
		    
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   
		
	} 
	
	
	public class ImageLoadTask extends AsyncTask<Void, Void, Bitmap> {

	    private String url;
	    private ImageSwitcher imageSwitcher;

	    public ImageLoadTask(String url, ImageSwitcher imageSwitcher) {
	        this.url = url;
	        this.imageSwitcher = imageSwitcher;
	    }

	    @Override
	    protected Bitmap doInBackground(Void... params) {
	        try {
	            URL urlConnection = new URL(url);
	            HttpURLConnection connection = (HttpURLConnection) urlConnection
	                    .openConnection();
	            connection.setDoInput(true);
	            connection.connect();
	            InputStream input = connection.getInputStream();
	            Bitmap myBitmap = BitmapFactory.decodeStream(input);
	            return myBitmap;
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return null;
	    }

	    @Override
	    protected void onPostExecute(Bitmap result) {
	        super.onPostExecute(result);
	        Drawable drawable = new BitmapDrawable(getApplicationContext().getResources(), result);
	        imageSwitcher.setImageDrawable(drawable);
	    }

	}
	
		
	
	
	public void next(View view){
	     /* Toast.makeText(getApplicationContext(), "Next Image", 
	      Toast.LENGTH_LONG).show();*/
	      Animation in = AnimationUtils.loadAnimation(this,
	      android.R.anim.slide_in_left);
	      Animation out = AnimationUtils.loadAnimation(this,
	      android.R.anim.slide_out_right);
	      imageSwitcher.setInAnimation(in);
	      imageSwitcher.setOutAnimation(out);
	      if(counter == 0 || counter == 1) {  
	    	  try{
	    		  new ImageLoadTask(imgUrl[counter+1], imageSwitcher).execute();
	    		  counter++;
	    		  if(counter == 1)
	    			  zest_info.setText("Historical Zestimate for the past 5 years");
	    		  else 
	    			  zest_info.setText("Historical Zestimate for the past 10 years");
		    	
	    	  }
	    	  catch(Exception ex){
	    		  ex.printStackTrace();
	    	  }
	    
	      }
	   }
	public void previous(View view){
	     /* Toast.makeText(getApplicationContext(), "previous Image", 
	      Toast.LENGTH_LONG).show();*/
	      Animation in = AnimationUtils.loadAnimation(this,
	      android.R.anim.slide_out_right);
	      Animation out = AnimationUtils.loadAnimation(this,
	      android.R.anim.slide_in_left);
	      imageSwitcher.setInAnimation(out);
	      imageSwitcher.setOutAnimation(in);
	      if(counter == 1 || counter == 2) {  
	    	  try{
	    		  new ImageLoadTask(imgUrl[counter-1], imageSwitcher).execute();
	    		  counter--;
	    		  if(counter == 0)
	    			  zest_info.setText("Historical Zestimate for the past 1 year");
	    		  else 
	    			  zest_info.setText("Historical Zestimate for the past 5 years");

	    	  }
	    	  catch(Exception ex){
	    		  ex.printStackTrace();
	    	  }
	    
	      }
	   }
	
	private void startFBActivity(String street, String city, String state, String zipcode,String homedetails, String price, String change, String img,String facebookShare){
    	Intent intent=new Intent(this,Post.class);
    	intent.putExtra("street",street);
    	intent.putExtra("city",city);
    	intent.putExtra("state", state);
    	intent.putExtra("zipcode", zipcode);
    	intent.putExtra("homedetails", homedetails);
    	intent.putExtra("price", price);
    	intent.putExtra("change", change);
       	intent.putExtra("img",img);
       	intent.putExtra("facebookVal",facebookShare);
    	startActivity(intent);
    	 return;
    }

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.result, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
