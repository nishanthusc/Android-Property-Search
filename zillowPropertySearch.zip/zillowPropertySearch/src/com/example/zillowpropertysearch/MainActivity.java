package com.example.zillowpropertysearch;


import java.net.URLEncoder;
//import java.util.*;

import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
//import org.json.JSONObject;

import android.support.v7.app.ActionBarActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.*;



public class MainActivity extends ActionBarActivity {
	 private Spinner spinner1;
	 // String EXTRA_MESSAGE = "com.example.myfirstapp.MESSAGE"; 
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       
        
        
        spinner1 = (Spinner) findViewById(R.id.spinner1);
		ArrayAdapter<CharSequence> dataAdapter = ArrayAdapter.createFromResource(this, R.array.array_states, android.R.layout.simple_spinner_item);            
	    dataAdapter.setDropDownViewResource
	                     (android.R.layout.simple_spinner_dropdown_item);
	       
	    spinner1.setAdapter(
	    	      new NothingSelectedSpinnerAdapter(
	    	            dataAdapter,
	    	            R.layout.contact_spinner_row_nothing_selected,
	    	            // R.layout.contact_spinner_nothing_selected_dropdown, // Optional
	    	            this));

	    //code to link the zillow image to zillow.com
	    ImageView img = (ImageView)findViewById(R.id.imageView1);
	    img.setOnClickListener(new View.OnClickListener(){
	        public void onClick(View v){
	            Intent intent = new Intent();
	            intent.setAction(Intent.ACTION_VIEW);
	            intent.addCategory(Intent.CATEGORY_BROWSABLE);
	            intent.setData(Uri.parse("http://www.zillow.com/"));
	            startActivity(intent);
	        }
	    });
        
        Button btnSearch = (Button)findViewById(R.id.btnSearch);
        btnSearch.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				//validateInputs(v);
				boolean addressStatus = true;
		    	boolean cityStatus = true;
		    	boolean stateStatus = true;
		    	EditText et1 =(EditText)findViewById(R.id.txtAddress);
		    	String address = et1.getText().toString().trim();
		    	if(address.equals("")){
		    		addressStatus = false;
		    		TextView tv1 = (TextView)findViewById(R.id.validation1);
		    		tv1.setText("This field is required");
		    		//setContentView(tv1);
		    	}
		    	
		    	
		    	EditText et2 =(EditText)findViewById(R.id.txtCity);
		    	String city = et2.getText().toString().trim();
		    	if(city.equals("")){
		    		cityStatus=false;
		    		TextView tv2 = (TextView)findViewById(R.id.validation2);
		    		tv2.setText("This field is required");
		    		//setContentView(tv2);
		    	}
		    	
		    	//Spinner sp2 = (Spinner)findViewById(R.id.spinner1);
		    	//String state = spinner1.getSelectedItem().toString();
		    	int selectedOptionPosition = spinner1.getSelectedItemPosition();
		    	if(selectedOptionPosition==0){
		    		stateStatus = false;
		    		TextView tv3 = (TextView)findViewById(R.id.validation3);
		    		tv3.setText("This field is required");
		    		//setContentView(tv3);
		    	}
		    	
		    	if(addressStatus&&cityStatus&&stateStatus){
		    		Toast.makeText(getBaseContext(),"Please wait, connecting to server.",Toast.LENGTH_LONG).show();
		    		new SendRequest().execute();
		    	}
			}
		});
	    
	      
       
    }
    /*public void addItemsOnSpinner2() {
    	 
    	Spinner spinner2 = (Spinner) findViewById(R.id.spinState);
    	List<String> list = new ArrayList<String>();
    	list.add("list 1");
    	list.add("list 2");
    	list.add("list 3");
    	ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
    		android.R.layout.simple_spinner_item, list);
    	dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
    	spinner2.setAdapter(dataAdapter);
      }*/

    
    
    
    private class SendRequest extends AsyncTask<Void, Void, Void> {
		String SetServerString;
		boolean success = false;
		@Override
		protected Void doInBackground(Void... params) {
			try {
				EditText streetInput = (EditText) findViewById(R.id.txtAddress);
        		String street = URLEncoder.encode(streetInput.getText().toString(), "UTF-8");
        		EditText cityInput = (EditText) findViewById(R.id.txtCity);
        		String city = URLEncoder.encode(cityInput.getText().toString(), "UTF-8");
        		Spinner spinner2 = (Spinner) findViewById(R.id.spinner1);
        		String state = URLEncoder.encode(spinner2.getSelectedItem().toString(), "UTF-8");
        		HttpClient Client = new DefaultHttpClient();
        		String url = "http://default-environment-kfepnj8tpz.elasticbeanstalk.com/?streetInput="+street+"&cityInput="+city+"&stateInput="+state;
        		//String url ="http://default-environment-kfepnj8tpz.elasticbeanstalk.com/?streetInput=2636+Menlo+Ave&cityInput=Los+Angeles&stateInput=CA";
        		Log.i("httpget", url);
        		try
                 {
                             // Create Request to server and get response
                     
                              HttpGet httpget = new HttpGet(url);
                              ResponseHandler<String> responseHandler = new BasicResponseHandler();
                              SetServerString = Client.execute(httpget, responseHandler);
                              if(!SetServerString.toString().trim().equals("")) 
                            	  success = true;
                              /*runOnUiThread(new Runnable() {
                            	  @Override
                            	public void run() {
                            		// TODO Auto-generated method stub
                            		  Toast.makeText(getBaseContext(),SetServerString,Toast.LENGTH_LONG).show();
                            	}
                              });*/
                              
                 }
        		 catch(Exception ex) {
        			// Log.e("log_tag", "Error in http connection "+ex.toString());
        			 ex.printStackTrace();
        			 SetServerString = ex.toString();
        		 }
        	}
        	catch(Exception ex) {
        		ex.printStackTrace();
   			 	SetServerString = ex.toString();
        	}
			return null;
		}
		@Override
		protected void onPostExecute(Void result) {
			if(SetServerString.toString().trim().equals("")) {
  			  	TextView txt = (TextView) findViewById(R.id.txtMessage);
  			  	txt.setText("No exact match found -- Verify that the given address is correct."); 
  		  	}
  		  	else if(success == true){
  		  		TextView txt = (TextView) findViewById(R.id.txtMessage);
			  	txt.setText(""); 
			  	try {
			  		//JSONObject response = new JSONObject(SetServerString);
			  		Intent intent = new Intent(MainActivity.this, ResultActivity.class);
			  		intent.putExtra("data", SetServerString);
			  		startActivity(intent);
			  		

			  	}
			  	catch(Exception ex) {
			  		ex.printStackTrace();
			  	}
			  
  		  		Toast.makeText(getBaseContext(),"Success",Toast.LENGTH_LONG).show();
  		  	}
  		  	else {
  		  		TextView txt = (TextView) findViewById(R.id.txtMessage);
			  	txt.setText("Error occured in application "+SetServerString); 
  		  	}
			// TODO Auto-generated method stub
			super.onPostExecute(result);
		}
	}
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
